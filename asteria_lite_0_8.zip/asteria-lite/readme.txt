The theme is licensed Under GNU GPL v2

The images slide1.jpg , slide2.jpg & slide3.jpg in the "images" folder are Public domain images.

Image credit links:
http://www.publicdomainpictures.net/view-image.php?image=18295&picture=frost&large=1
http://www.publicdomainpictures.net/view-image.php?image=28733&picture=morning-frost&large=1
http://www.publicdomainpictures.net/view-image.php?image=34973&picture=water&large=1


All other graphics used in this theme is desgined by me and licensed under GNU GPL v2


Limitations: 

#The top menu space is limited. If you assign lots of menu item to the menu position it may break.
# IE6, IE7, IE8 is not compatible. 

