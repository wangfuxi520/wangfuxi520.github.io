<?php get_header(); ?>
<?php global $asteria;?>
<!--Categoryt Posts-->
<div class="fixed_site">
	<div class="fixed_wrap">
		<?php get_template_part('layout1'); ?>
	</div>
</div>
<?php get_footer(); ?>